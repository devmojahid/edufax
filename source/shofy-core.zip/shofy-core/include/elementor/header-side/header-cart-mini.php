<?php if (class_exists( 'WooCommerce' ) ): ?>  
<?php print shofy_shopping_cart(); ?>
<div class="body-overlay"></div>
<?php endif; ?>